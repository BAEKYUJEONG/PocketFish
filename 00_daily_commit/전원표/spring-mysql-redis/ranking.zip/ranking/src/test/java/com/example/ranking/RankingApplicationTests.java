package com.example.ranking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
